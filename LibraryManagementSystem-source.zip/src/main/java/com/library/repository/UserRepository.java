package com.library.repository;

import com.library.model.User;
import com.library.singleton.LibraryDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UserRepository implements Repository<User, String> {
    private final LibraryDatabase db = LibraryDatabase.getInstance();

    @Override
    public void save(User user) { db.putUser(user); }

    @Override
    public Optional<User> findById(String id) { return db.getUser(id); }

    @Override
    public List<User> findAll() { return new ArrayList<>(db.getAllUsers()); }

    @Override
    public void delete(String id) { db.removeUser(id); }

    public Optional<User> findByEmail(String email) {
        return db.getAllUsers().stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }
}
