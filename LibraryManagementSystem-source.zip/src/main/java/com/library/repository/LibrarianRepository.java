package com.library.repository;

import com.library.model.Librarian;
import com.library.singleton.LibraryDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class LibrarianRepository implements Repository<Librarian, String> {
    private final LibraryDatabase db = LibraryDatabase.getInstance();

    @Override
    public void save(Librarian l) { db.putLibrarian(l); }

    @Override
    public Optional<Librarian> findById(String id) { return db.getLibrarian(id); }

    @Override
    public List<Librarian> findAll() { return new ArrayList<>(db.getAllLibrarians()); }

    @Override
    public void delete(String id) { db.removeLibrarian(id); }

    public Optional<Librarian> findByEmployeeId(String employeeId) {
        return db.getAllLibrarians().stream()
                .filter(l -> l.getEmployeeId().equals(employeeId))
                .findFirst();
    }
}
