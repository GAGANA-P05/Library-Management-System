package com.library.repository;

import com.library.model.Book;
import com.library.singleton.LibraryDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookRepository implements Repository<Book, String> {
    private final LibraryDatabase db = LibraryDatabase.getInstance();

    @Override
    public void save(Book book) { db.putBook(book); }

    @Override
    public Optional<Book> findById(String id) { return db.getBook(id); }

    @Override
    public List<Book> findAll() { return new ArrayList<>(db.getAllBooks()); }

    @Override
    public void delete(String id) { db.removeBook(id); }

    public List<Book> findByCategory(String category) {
        List<Book> result = new ArrayList<>();
        for (Book b : db.getAllBooks())
            if (b.getCategory().equalsIgnoreCase(category)) result.add(b);
        return result;
    }

    public Optional<Book> findByIsbn(String isbn) {
        return db.getAllBooks().stream()
                .filter(b -> b.getIsbn().equalsIgnoreCase(isbn))
                .findFirst();
    }
}
