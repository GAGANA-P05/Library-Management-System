package com.library.repository;

import com.library.model.Notification;
import com.library.singleton.LibraryDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class NotificationRepository implements Repository<Notification, String> {
    private final LibraryDatabase db = LibraryDatabase.getInstance();

    @Override
    public void save(Notification n) { db.putNotification(n); }

    @Override
    public Optional<Notification> findById(String id) { return db.getNotification(id); }

    @Override
    public List<Notification> findAll() { return new ArrayList<>(db.getAllNotifications()); }

    @Override
    public void delete(String id) { /* notifications kept for audit */ }

    public List<Notification> findByUserId(String userId) {
        return db.getAllNotifications().stream()
                .filter(n -> n.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
}
