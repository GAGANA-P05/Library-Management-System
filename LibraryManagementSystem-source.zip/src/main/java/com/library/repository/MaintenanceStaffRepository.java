package com.library.repository;

import com.library.enums.StaffRole;
import com.library.model.MaintenanceStaff;
import com.library.singleton.LibraryDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MaintenanceStaffRepository implements Repository<MaintenanceStaff, String> {
    private final LibraryDatabase db = LibraryDatabase.getInstance();

    @Override
    public void save(MaintenanceStaff s) { db.putMaintenanceStaff(s); }

    @Override
    public Optional<MaintenanceStaff> findById(String id) { return db.getMaintenanceStaff(id); }

    @Override
    public List<MaintenanceStaff> findAll() { return new ArrayList<>(db.getAllMaintenanceStaff()); }

    @Override
    public void delete(String id) { db.removeMaintenanceStaff(id); }

    public List<MaintenanceStaff> findByRole(StaffRole role) {
        return db.getAllMaintenanceStaff().stream()
                .filter(s -> s.getRole() == role)
                .collect(Collectors.toList());
    }
}
