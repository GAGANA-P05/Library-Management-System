package com.library.repository;

import com.library.model.Transaction;
import com.library.singleton.LibraryDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class TransactionRepository implements Repository<Transaction, String> {
    private final LibraryDatabase db = LibraryDatabase.getInstance();

    @Override
    public void save(Transaction t) { db.putTransaction(t); }

    @Override
    public Optional<Transaction> findById(String id) { return db.getTransaction(id); }

    @Override
    public List<Transaction> findAll() { return new ArrayList<>(db.getAllTransactions()); }

    @Override
    public void delete(String id) { /* transactions are never hard-deleted */ }

    public List<Transaction> findByUserId(String userId) {
        return db.getAllTransactions().stream()
                .filter(t -> t.getUserId().equals(userId))
                .collect(Collectors.toList());
    }

    public List<Transaction> findByBookId(String bookId) {
        return db.getAllTransactions().stream()
                .filter(t -> t.getBookId().equals(bookId))
                .collect(Collectors.toList());
    }

    public Optional<Transaction> findActiveByBookId(String bookId) {
        return db.getAllTransactions().stream()
                .filter(t -> t.getBookId().equals(bookId) &&
                        (t.getStatus().name().equals("ISSUED") ||
                         t.getStatus().name().equals("OVERDUE")))
                .findFirst();
    }
}
