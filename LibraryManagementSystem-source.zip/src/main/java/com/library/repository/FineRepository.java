package com.library.repository;

import com.library.model.Fine;
import com.library.singleton.LibraryDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class FineRepository implements Repository<Fine, String> {
    private final LibraryDatabase db = LibraryDatabase.getInstance();

    @Override
    public void save(Fine fine) { db.putFine(fine); }

    @Override
    public Optional<Fine> findById(String id) { return db.getFine(id); }

    @Override
    public List<Fine> findAll() { return new ArrayList<>(db.getAllFines()); }

    @Override
    public void delete(String id) { /* fines are audit records – never deleted */ }

    public List<Fine> findByUserId(String userId) {
        return db.getAllFines().stream()
                .filter(f -> f.getUserId().equals(userId))
                .collect(Collectors.toList());
    }

    public List<Fine> findUnpaidByUserId(String userId) {
        return db.getAllFines().stream()
                .filter(f -> f.getUserId().equals(userId) && !f.isPaid())
                .collect(Collectors.toList());
    }

    public Optional<Fine> findByTransactionId(String transactionId) {
        return db.getAllFines().stream()
                .filter(f -> f.getTransactionId().equals(transactionId))
                .findFirst();
    }

    public double totalCollected() {
        return db.getAllFines().stream()
                .filter(Fine::isPaid)
                .mapToDouble(Fine::getFineAmount)
                .sum();
    }
}
