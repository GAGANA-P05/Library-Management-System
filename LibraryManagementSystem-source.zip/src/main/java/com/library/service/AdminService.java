package com.library.service;

import com.library.model.Admin;
import com.library.singleton.LibraryDatabase;

import java.util.Optional;

public class AdminService {

    private final LibraryDatabase db = LibraryDatabase.getInstance();

    public Optional<Admin> authenticate(String username, String password) {
        return db.getAllAdmins().stream()
                .filter(a -> a.authenticate(username, password))
                .findFirst();
    }

    public void addAdmin(Admin admin) {
        db.putAdmin(admin);
    }

    public Optional<Admin> findById(String adminId) {
        return db.getAdmin(adminId);
    }
}
