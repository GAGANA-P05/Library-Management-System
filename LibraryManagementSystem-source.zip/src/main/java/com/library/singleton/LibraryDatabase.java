package com.library.singleton;

import com.library.model.*;
import java.util.*;

/**
 * Singleton pattern: single shared in-memory data store for the entire application.
 */
public class LibraryDatabase {

    private static LibraryDatabase instance;

    private final Map<String, Book>             books             = new LinkedHashMap<>();
    private final Map<String, User>             users             = new LinkedHashMap<>();
    private final Map<String, Librarian>        librarians        = new LinkedHashMap<>();
    private final Map<String, Admin>            admins            = new LinkedHashMap<>();
    private final Map<String, Transaction>      transactions      = new LinkedHashMap<>();
    private final Map<String, Fine>             fines             = new LinkedHashMap<>();
    private final Map<String, Notification>     notifications     = new LinkedHashMap<>();
    private final Map<String, MaintenanceStaff> maintenanceStaff  = new LinkedHashMap<>();

    private LibraryDatabase() {}

    public static synchronized LibraryDatabase getInstance() {
        if (instance == null) instance = new LibraryDatabase();
        return instance;
    }

    // ── Books ──────────────────────────────────────────────────────────────
    public void putBook(Book b)              { books.put(b.getBookId(), b); }
    public Optional<Book> getBook(String id) { return Optional.ofNullable(books.get(id)); }
    public void removeBook(String id)        { books.remove(id); }
    public Collection<Book> getAllBooks()    { return books.values(); }

    // ── Users ──────────────────────────────────────────────────────────────
    public void putUser(User u)              { users.put(u.getUserId(), u); }
    public Optional<User> getUser(String id) { return Optional.ofNullable(users.get(id)); }
    public void removeUser(String id)        { users.remove(id); }
    public Collection<User> getAllUsers()    { return users.values(); }

    // ── Librarians ─────────────────────────────────────────────────────────
    public void putLibrarian(Librarian l)              { librarians.put(l.getLibrarianId(), l); }
    public Optional<Librarian> getLibrarian(String id) { return Optional.ofNullable(librarians.get(id)); }
    public void removeLibrarian(String id)             { librarians.remove(id); }
    public Collection<Librarian> getAllLibrarians()    { return librarians.values(); }

    // ── Admins ─────────────────────────────────────────────────────────────
    public void putAdmin(Admin a)              { admins.put(a.getAdminId(), a); }
    public Optional<Admin> getAdmin(String id) { return Optional.ofNullable(admins.get(id)); }
    public Collection<Admin> getAllAdmins()    { return admins.values(); }

    // ── Transactions ───────────────────────────────────────────────────────
    public void putTransaction(Transaction t)              { transactions.put(t.getTransactionId(), t); }
    public Optional<Transaction> getTransaction(String id) { return Optional.ofNullable(transactions.get(id)); }
    public Collection<Transaction> getAllTransactions()    { return transactions.values(); }

    // ── Fines ──────────────────────────────────────────────────────────────
    public void putFine(Fine f)              { fines.put(f.getFineId(), f); }
    public Optional<Fine> getFine(String id) { return Optional.ofNullable(fines.get(id)); }
    public Collection<Fine> getAllFines()    { return fines.values(); }

    // ── Notifications ──────────────────────────────────────────────────────
    public void putNotification(Notification n)              { notifications.put(n.getNotificationId(), n); }
    public Optional<Notification> getNotification(String id) { return Optional.ofNullable(notifications.get(id)); }
    public Collection<Notification> getAllNotifications()    { return notifications.values(); }

    // ── Maintenance Staff ──────────────────────────────────────────────────
    public void putMaintenanceStaff(MaintenanceStaff s)              { maintenanceStaff.put(s.getStaffId(), s); }
    public Optional<MaintenanceStaff> getMaintenanceStaff(String id) { return Optional.ofNullable(maintenanceStaff.get(id)); }
    public void removeMaintenanceStaff(String id)                    { maintenanceStaff.remove(id); }
    public Collection<MaintenanceStaff> getAllMaintenanceStaff()     { return maintenanceStaff.values(); }
}
